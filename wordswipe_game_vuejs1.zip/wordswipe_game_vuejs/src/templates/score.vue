<template>
  <section class="app-score">
    <span class="score-item">
      <div class="label">TIME</div>
      <div class="text">{{time}}</div>
    </span>
    <span class="score-item">
      <div class="label">SCORE</div>
      <div class="text">{{score}}</div>
    </span>
    <span class="score-item">
      <div class="label">BEST</div>
      <div class="text">{{best}}</div>
    </span>
  </section>
</template>

<script type="text/javascript" src="../js/score.js"></script>
<style lang="less" src="../styles/score.less"></style>