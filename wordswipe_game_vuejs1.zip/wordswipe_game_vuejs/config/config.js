
export default {
    Services: {
        server: '',
        wordlist: '/static/dictionary.json'
    }
}
